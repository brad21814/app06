(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_5ea20161._.js",
  "static/chunks/_8c09f4d7._.js"
],
    source: "dynamic"
});
