(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_af6240d9._.js",
  "static/chunks/node_modules_next_dist_compiled_react-dom-experimental_375bf58e._.js",
  "static/chunks/node_modules_next_dist_compiled_d87e34ab._.js",
  "static/chunks/node_modules_next_dist_client_72eb3285._.js",
  "static/chunks/node_modules_next_dist_2cf6886d._.js",
  "static/chunks/node_modules_@swc_helpers_cjs_00636ac3._.js"
],
    source: "entry"
});
