(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_75211bf5._.js",
  "static/chunks/_cdce1d9b._.js"
],
    source: "dynamic"
});
