(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__48d1951a._.css",
  "static/chunks/d9ef2_@firebase_auth_dist_esm_279e5069._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm_bf7383cb.js",
  "static/chunks/node_modules_61012c29._.js",
  "static/chunks/lib_firebase_474002da._.js"
],
    source: "dynamic"
});
